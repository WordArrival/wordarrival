using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Threading;

[assembly: AssemblyTitle("단어왔어")]
[assembly: AssemblyVersion("1.0.1.0")]
[assembly: AssemblyFileVersion("1.0.1.0")]

public class Card {
    public string key, word, meaning, pos;
    public bool featured;
    public int level;
    public string[] examples, translations, choices;
}
public class Record {
    public int stage, example;
    public DateTime due;
    public bool retired;
    public string result, day;
}
public class Settings {
    public int minutes = 30, level;
    public bool featured = true, paused, nightly = true, cloze;
    public string notifiedDay;
    public Dictionary<string,Record> records = new Dictionary<string,Record>();
}
public class StudyApp : ApplicationContext {
    static readonly string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WordArrival");
    static readonly string path = Path.Combine(folder,"learning.json");
    static readonly JavaScriptSerializer json = new JavaScriptSerializer { MaxJsonLength = 100000000 };
    readonly Settings settings;
    readonly List<Card> cards;
    readonly Random random = new Random();
    readonly NotifyIcon tray = new NotifyIcon();
    readonly ContextMenuStrip menu = new ContextMenuStrip();
    readonly System.Windows.Forms.Timer clock = new System.Windows.Forms.Timer { Interval = 1000 };
    DateTime next;
    Form active;
    string notice;
    Card pending;
    readonly Icon appIcon;
    static readonly Color navy = Color.FromArgb(26,47,69), coral = Color.FromArgb(165,59,45), paper = Color.FromArgb(255,249,236);
    static string Today { get { return DateTime.Now.ToString("yyyy-MM-dd"); } }
    static readonly int[] days = {1,3,7,14,30,60};
    public StudyApp() {
        Directory.CreateDirectory(folder);
        settings = Load();
        using (var reader = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("cards.json"), Encoding.UTF8))
            cards = json.Deserialize<List<Card>>(reader.ReadToEnd());
        appIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        tray.Icon = appIcon;
        tray.Text = "단어왔어 1.0.1 · 두 번 클릭해 문제 풀기";
        tray.ContextMenuStrip = menu;
        tray.DoubleClick += delegate { Quiz(null); };
        tray.BalloonTipClicked += delegate { if (notice == "night") ListWindow(true); else Quiz(pending); };
        Menu();
        tray.Visible = true;
        clock.Tick += delegate { Tick(); };
        next = DateTime.Now;
        clock.Start();
    }
    static Settings Load() {
        if (!File.Exists(path)) return new Settings();
        try { return json.Deserialize<Settings>(File.ReadAllText(path)) ?? new Settings(); }
        catch {
            string backup = path + ".bak";
            if (File.Exists(backup)) return json.Deserialize<Settings>(File.ReadAllText(backup));
            throw new InvalidDataException("학습 기록을 열 수 없어요. " + path);
        }
    }
    void Save() {
        try {
            string temp = path + ".tmp";
            File.WriteAllText(temp,json.Serialize(settings),new UTF8Encoding(false));
            if (File.Exists(path)) File.Replace(temp,path,path+".bak"); else File.Move(temp,path);
        } catch (IOException e) { MessageBox.Show("기록 저장을 마치지 못했어요. " + e.Message,"단어왔어"); }
    }
    void ResetTimer() { next = DateTime.Now.AddMinutes(settings.minutes); }
    ToolStripMenuItem Entry(ToolStripItemCollection parent,string label,Action act,bool check) {
        var item = new ToolStripMenuItem(label){Checked=check};
        item.Click += delegate { act(); Save(); Menu(); };
        parent.Add(item); return item;
    }
    void Menu() {
        menu.Items.Clear();
        var items = menu.Items;
        items.Add("지금 한 문제 풀기",null,delegate { Quiz(null); });
        items.Add("오늘의 복습",null,delegate { ListWindow(true); });
        items.Add("학습 기록",null,delegate { ListWindow(false); });
        var pack = new ToolStripMenuItem("단어장"); items.Add(pack);
        Entry(pack.DropDownItems,"대표 100문제",delegate { settings.featured=true; pending=null; },settings.featured);
        Entry(pack.DropDownItems,"기본 7,452단어",delegate { settings.featured=false; pending=null; },!settings.featured);
        var level = new ToolStripMenuItem("기본 단어장 수준"); items.Add(level);
        foreach (int n in new int[]{0,1,2}) {
            int value=n;
            Entry(level.DropDownItems,new string[]{"전체","중등","고등"}[n],delegate { settings.level=value; pending=null; },settings.level==n);
        }
        Entry(items,"빈칸 단어 맞히기",delegate { settings.cloze=!settings.cloze; },settings.cloze);
        var interval = new ToolStripMenuItem("출제 간격"); items.Add(interval);
        foreach(int n in new int[]{1,5,10,15,30,45,60}) {
            int value=n;
            Entry(interval.DropDownItems,n+"분",delegate { settings.minutes=value; ResetTimer(); },settings.minutes==n);
        }
        Entry(items,"자동 출제 일시 정지",delegate {settings.paused=!settings.paused; ResetTimer();},settings.paused);
        Entry(items,"밤 10시 복습 알림",delegate {settings.nightly=!settings.nightly;},settings.nightly);
        items.Add("개발자 후원하기", null, delegate {
            const string address = "https://wordarrival.github.io/wordarrival/support.html";
            try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(address) { UseShellExecute = true }); }
            catch (System.ComponentModel.Win32Exception) { MessageBox.Show("브라우저에서 다음 주소를 열어주세요.\n" + address, "개발자 후원하기"); }
        });
        items.Add("단어장 출처",null,delegate { System.Diagnostics.Process.Start(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Credits")); });
        items.Add("종료",null,delegate { ExitThread(); });
    }
    Card Pick() {
        var pool=cards.Where(c=>c.featured==settings.featured && (c.featured || settings.level==0 || c.level==settings.level));
        var due=pool.Where(c=>settings.records.ContainsKey(c.key)).Where(c=>!settings.records[c.key].retired && settings.records[c.key].due<=DateTime.UtcNow)
            .OrderBy(c=>settings.records[c.key].due).FirstOrDefault();
        if(due!=null) return due;
        var fresh=pool.Where(c=>!settings.records.ContainsKey(c.key)).ToList();
        return fresh.Count==0 ? null : fresh[random.Next(fresh.Count)];
    }
    void Tick() {
        if(settings.paused || active!=null) return;
        if(settings.nightly && DateTime.Now.Hour>=22 && settings.notifiedDay!=Today && settings.records.Values.Any(r=>r.day==Today)) {
            notice="night"; pending=null;
            tray.ShowBalloonTip(12000,"오늘의 복습","오늘 배운 단어와 예문을 다시 보세요.",ToolTipIcon.Info);
            settings.notifiedDay=Today; Save(); ResetTimer(); return;
        }
        if(DateTime.Now<next) return;
        ResetTimer(); pending=Pick(); notice="quiz";
        if(pending!=null) tray.ShowBalloonTip(12000,"단어왔어 · "+pending.word,pending.examples[ExampleFor(pending)],ToolTipIcon.Info);
    }
    int ExampleFor(Card c) {
        Record r;
        return settings.records.TryGetValue(c.key,out r) ? (r.example+1)%c.examples.Length : 0;
    }
    Form Window(string title,int width,int height) {
        if(active!=null) active.Close();
        var f=new Form { Text="단어왔어 · "+title, ClientSize=new Size(width,height), BackColor=paper, ForeColor=navy,
            Font=new Font("Malgun Gothic",10), StartPosition=FormStartPosition.CenterScreen, Icon=appIcon,
            AutoScaleMode=AutoScaleMode.Dpi, MinimumSize=new Size(width,height) };
        active=f; f.FormClosed+=delegate { active=null; ResetTimer(); };
        return f;
    }
    static Label LabelAt(Form f,string text,int x,int y,int w,int h,float size,bool bold) {
        var l=new Label { Text=text, Location=new Point(x,y), Size=new Size(w,h), AutoEllipsis=true, UseMnemonic=false,
            Font=new Font("Malgun Gothic",size,bold ? FontStyle.Bold : FontStyle.Regular) }; f.Controls.Add(l); return l;
    }
    static Button ButtonAt(Form f,string text,int x,int y,int w,int h,Action action) {
        var b=new Button { Text=text, Location=new Point(x,y), Size=new Size(w,h), BackColor=Color.White, ForeColor=navy, UseMnemonic=false };
        b.Click+=delegate { action(); }; f.Controls.Add(b); return b;
    }
    void Quiz(Card selection) {
        if(active!=null) { active.Activate(); return; }
        var c=selection ?? Pick(); pending=null;
        if(c==null) { MessageBox.Show("현재 단어장의 다음 복습을 기다려 주세요.","단어왔어"); return; }
        int index=ExampleFor(c);
        bool cloze=settings.cloze;
        string example=c.examples[index];
        string blank=System.Text.RegularExpressions.Regex.Replace(example,@"\b"+System.Text.RegularExpressions.Regex.Escape(c.word)+@"\b","____",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if(blank==example) cloze=false;
        string expected=cloze ? c.word : c.meaning;
        var f=Window("오늘의 한 단어",475,498);
        LabelAt(f,cloze?"빈칸에 들어갈 단어를 고르세요":"문장 속 뜻을 고르세요",18,12,440,25,10,false).ForeColor=coral;
        LabelAt(f,cloze?c.meaning:c.word,18,43,441,52,23,true);
        LabelAt(f,cloze?blank:example,18,100,441,64,12,false);
        var options=(cloze ? cards.Where(v=>v.word!=c.word && v.meaning!=c.meaning && v.pos==c.pos).Select(v=>v.word).Distinct().OrderBy(v=>random.Next()).Take(3) : c.choices.AsEnumerable())
            .Concat(new string[]{expected}).Distinct().OrderBy(v=>random.Next()).ToList();
        bool answered=false;
        var controls=new List<Button>();
        var result=LabelAt(f,"",18,363,438,79,10,false);
        Action<string> answer=delegate(string outcome) {
            if(answered) return;
            answered=true;
            Record r;
            if(!settings.records.TryGetValue(c.key,out r)) r=new Record();
            r.stage=outcome=="정답" ? Math.Min(r.stage+1,days.Length) : 0;
            r.retired=outcome=="이미 아는 뜻"; r.result=outcome; r.day=Today; r.example=index;
            r.due=DateTime.Now.AddDays(r.stage==0 ? 1 : days[r.stage-1]).ToUniversalTime(); settings.records[c.key]=r; Save();
            foreach(var b in controls) b.Enabled=false;
            result.Text=outcome+" · "+c.word+" · "+c.meaning+Environment.NewLine+c.translations[index];
        };
        for(int i=0;i<options.Count;i++) {
            string choice=options[i];
            controls.Add(ButtonAt(f,choice,18,165+i*36,438,33,delegate { answer(choice==expected?"정답":"오답"); }));
        }
        controls.Add(ButtonAt(f,"모르겠어요",18,317,126,34,delegate { answer("모르겠어요"); }));
        controls.Add(ButtonAt(f,"이미 아는 뜻",152,317,126,34,delegate { answer("이미 아는 뜻"); }));
        ButtonAt(f,"5분 뒤 다시",18,450,126,32,delegate { f.Close(); next=DateTime.Now.AddMinutes(5); });
        ButtonAt(f,"닫기",346,450,110,32,delegate { f.Close(); });
        f.Show(); f.Activate();
    }
    void ListWindow(bool today) {
        if(active!=null) { active.Activate(); return; }
        var f=Window(today?"오늘의 복습":"학습 기록",570,470);
        var text=new RichTextBox { Dock=DockStyle.Fill, ReadOnly=true, BackColor=paper, ForeColor=navy, BorderStyle=BorderStyle.None, DetectUrls=false };
        var toggle=new CheckBox { Dock=DockStyle.Top, Height=40,Text="뜻과 해석 보기",Checked=true };
        var rows=cards.Where(c=>settings.records.ContainsKey(c.key) && (!today || settings.records[c.key].day==Today))
            .OrderByDescending(c=>settings.records[c.key].result=="모르겠어요" || settings.records[c.key].result=="오답").ThenBy(c=>c.word).ToList();
        Action refresh=delegate {
            var body=new StringBuilder();
            foreach(Card c in rows) {
                Record r=settings.records[c.key]; int idx=Math.Min(r.example,c.examples.Length-1);
                body.AppendLine(c.word+"  ·  "+r.result);
                if(toggle.Checked) body.AppendLine(c.meaning);
                body.AppendLine(c.examples[idx]);
                if(toggle.Checked) body.AppendLine(c.translations[idx]);
                body.AppendLine();
            }
            text.Text=rows.Count==0 ? "문제를 풀면 이곳에 단어와 예문이 모여요." : body.ToString();
        };
        toggle.CheckedChanged+=delegate { refresh(); };
        f.Padding=new Padding(16); f.Controls.Add(text); f.Controls.Add(toggle); refresh(); f.Show(); f.Activate();
    }
    protected override void ExitThreadCore() { clock.Stop(); tray.Visible=false; tray.Dispose(); base.ExitThreadCore(); }
    [STAThread] public static void Main() {
        bool first;
        using(var mutex=new Mutex(true,"Local\\WordArrival1",out first)) {
            if(!first) { MessageBox.Show("단어왔어가 이미 실행 중이에요. 작업 표시줄의 단어왔어 아이콘을 열어주세요."); return; }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try { Application.Run(new StudyApp()); }
            catch(Exception ex) { MessageBox.Show(ex.Message,"단어왔어를 열 수 없어요"); }
        }
    }
}
