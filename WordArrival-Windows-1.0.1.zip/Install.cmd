@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0" || goto :fail
set "compiler=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%compiler%" (
  echo Microsoft .NET Framework 4.x is required.
  goto :fail
)
set "target=%LocalAppData%\Programs\WordArrival"
if not exist "%target%" mkdir "%target%"
if not exist "%target%" goto :fail
set "pending=%target%\WordArrival-%RANDOM%-%RANDOM%.exe"
"%compiler%" /nologo /target:winexe /platform:anycpu /optimize+ /codepage:65001 /win32icon:App.ico /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:System.Core.dll /resource:cards.json,cards.json /out:"%pending%" WordArrival.cs
if errorlevel 1 goto :fail
xcopy /i /e /y "Credits" "%target%\Credits" >nul
if errorlevel 1 goto :fail
move /y "%pending%" "%target%\WordArrival.exe" >nul
if errorlevel 1 (
  echo Close WordArrival in the system tray and try again.
  goto :fail
)
powershell.exe -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) 'WordArrival.lnk')); $s.TargetPath=Join-Path $env:target 'WordArrival.exe'; $s.Save()"
if errorlevel 1 echo Start menu shortcut unavailable. Open "%target%\WordArrival.exe" to start.
start "" "%target%\WordArrival.exe"
exit /b 0
:fail
if defined pending if exist "%pending%" del "%pending%"
echo Installation did not finish.
pause
exit /b 1
